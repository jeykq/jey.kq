<?php
if ($_SESSION['adminloggedIn']) {
    
} else {
    header("Location: https://18.212.3.55/LoginPage.php");
}