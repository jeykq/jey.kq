<?php
if ($_SESSION['loggedIn']) {
    
} else {
    header("Location: https://18.212.3.55/LoginPage.php");
}